import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from core.atmosphere import isa
from core.cycle_solver import CycleInputs, solve_cycle
def test_isa():
    for alt, T, P in [(0, 288.15, 101325), (11000, 216.65, 22632.1), (20000, 216.65, 5474.9)]:
        t, p, *_ = isa(alt); assert abs(t - T) < .01 and abs(p / P - 1) < 2e-4, (alt, t, p)
def test_cycle():
    r = solve_cycle(CycleInputs(11000, .8, 8, 1.6, 25, 1700, thrust_N=60e3))
    assert abs(r["checks"]["spool_hp_residual_W"]) < 1 and abs(r["checks"]["spool_lp_residual_W"]) < 1
    assert r["checks"]["propulsive_le_1"] and r["eta_propulsive"] > 0.6
    assert 0.2 < r["eta_overall"] < 0.5 and 8 < r["tsfc_mg_per_Ns"] < 25, r
    print({k: round(r[k], 4) for k in ["f", "specific_thrust_N_per_kgs", "tsfc_mg_per_Ns", "m_total", "eta_thermal", "eta_propulsive", "A9_m2", "A19_m2"]})
    print("core choked:", r["core_nozzle"]["choked"], "bypass choked:", r["bypass_nozzle"]["choked"])
if __name__ == "__main__": test_isa(); test_cycle(); print("OK")

def test_ab_sizing_validation():
    from core.component_sizing import size_fan, size_nozzles
    from core.validation import validate
    from core.engine_selector import recommend
    dry = solve_cycle(CycleInputs(0, 0.0, 0.5, 3.0, 8, 1600, thrust_N=40e3))
    wet = solve_cycle(CycleInputs(0, 0.0, 0.5, 3.0, 8, 1600, thrust_N=40e3, t7=2000))
    assert wet["specific_thrust_N_per_kgs"] > dry["specific_thrust_N_per_kgs"] and wet["tsfc_mg_per_Ns"] > dry["tsfc_mg_per_Ns"]
    print("dry/wet Fs:", round(dry["specific_thrust_N_per_kgs"]), round(wet["specific_thrust_N_per_kgs"]),
          "TSFC:", round(dry["tsfc_mg_per_Ns"], 1), round(wet["tsfc_mg_per_Ns"], 1))
    fan = size_fan(dry); print("fan D [m]:", round(fan["tip_diameter"]["value"], 3), "rpm", round(fan["rotational_speed"]["value"]))
    print(validate(dry, fan)["status"], recommend(0.8, 8, False)["recommended"], "|", recommend(1.8, 0.4, True)["recommended"])
    size_nozzles(wet)
test_ab_sizing_validation() if __name__ == "__main__" else None

def test_optimiser():
    from core.optimization import optimise
    b = CycleInputs(10668, .8, 6, 1.6, 20, 1450, thrust_N=26270)
    o = optimise(b, "tsfc", d_max=3.0, maxiter=10)
    assert o["feasible"] and o["result"]["tsfc_mg_per_Ns"] <= solve_cycle(b)["tsfc_mg_per_Ns"] + 1e-9
test_optimiser() if __name__ == "__main__" else None

def test_new_physics():
    from core.cycle_solver import CycleInputs as C
    from core.performance import lapse, sensitivity
    from core.mission import breguet
    from visualization.cycle_diagrams import ts_data
    b = C(10668, .8, 6, 1.6, 20, 1450, thrust_N=26270); r = solve_cycle(b)
    assert abs(r["checks"]["energy_balance_rel"]) < 1e-9, r["checks"]
    rc = solve_cycle(C(10668, .8, 6, 1.6, 20, 1450, thrust_N=26270, cd_nozzles=True))
    assert rc["thrust_N"] > 0 and rc["tsfc_mg_per_Ns"] < r["tsfc_mg_per_Ns"] and rc["A9_m2"] >= rc["A9_throat_m2"]
    # lapse at the design point must reproduce the design thrust
    row = lapse(b, r, [10668], [0.8])[0]; assert abs(row["thrust_N"] / 26270 - 1) < 1e-6, row
    sl = lapse(b, r, [0], [0.0])[0]; assert sl["thrust_N"] > 26270 * 2          # sea-level static >> cruise
    assert abs(sensitivity(b)[3]["tsfc"]) > 0 and ts_data(r)["core"][0]["T"] > 200
    assert breguet(236, 1.5e-5, 17, 70000, 60000)["range_m"] > 1e6
    print("lapse SLS/cruise thrust:", round(sl["thrust_N"] / 26270, 2), "| CD TSFC gain:", round(1 - rc["tsfc_mg_per_Ns"] / r["tsfc_mg_per_Ns"], 3))
test_new_physics() if __name__ == "__main__" else None
