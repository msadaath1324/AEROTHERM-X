"""Three.js engine viewer. Calculated (from solver): fan tip/hub diameter, core-face diameter, nozzle exit areas.
SCHEMATIC (not sized): axial lengths of compressor/combustor/turbine and their radii between stations.
Every part is tagged 'calculated' or 'schematic' in the annotation text."""
import json, math

def build_dims(res, fan, core, wet=False):
    R = fan["tip_diameter"]["value"] / 2
    r9 = math.sqrt(res["A9_m2"] / math.pi)
    A19 = res["A19_m2"]
    return dict(R=R, rhub=fan["hub_diameter"]["value"] / 2, rcore=core["tip_diameter"] / 2, r9=r9,
                r19o=R * 0.95, r19i=math.sqrt(max((R * 0.95) ** 2 - A19 / math.pi, 0.0)), wet=wet,
                choked=res["core_nozzle"]["choked"], A9=res["A9_m2"], A19=A19, D=2 * R)

_HTML = """<style>html,body{margin:0;background:#080D16;color:#EAF1F8;font:12px sans-serif;overflow:hidden}
#bar{position:absolute;top:8px;left:8px;z-index:5;display:flex;flex-wrap:wrap;gap:4px;max-width:96%}
button,select{background:#111A27;color:#82B9FF;border:1px solid #2a3b52;padding:4px 8px;cursor:pointer}
button.on{border-color:#35D6F2;color:#35D6F2}.lb{position:absolute;color:#EAF1F8;background:#111A27cc;padding:1px 5px;border-left:2px solid #35D6F2;pointer-events:none;white-space:nowrap}
#note{position:absolute;bottom:6px;left:8px;color:#8CA0B8}</style>
<div id="bar"></div><div id="note"></div>
<script type="importmap">{"imports":{"three":"https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js","three/addons/":"https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/"}}</script>
<script type="module">
import * as THREE from 'three'; import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
const d=__DIMS__; const R=d.R, L=R*4.2;
const sc=new THREE.Scene(), cam=new THREE.PerspectiveCamera(40,innerWidth/innerHeight,.01,100);
cam.position.set(L*.5,R*2.2,R*3.5); const rn=new THREE.WebGLRenderer({antialias:true}); rn.setSize(innerWidth,innerHeight); rn.localClippingEnabled=true; document.body.appendChild(rn.domElement);
const ctl=new OrbitControls(cam,rn.domElement); ctl.target.set(L*.4,0,0); sc.add(new THREE.AmbientLight(0xffffff,.7)); const dl=new THREE.DirectionalLight(0xffffff,1.1); dl.position.set(1,2,1.5); sc.add(dl);
const plane=new THREE.Plane(new THREE.Vector3(0,0,-1),0);
// profiles: [radius, x] pairs; revolved about the x axis
const x=(f)=>f*L, P=[
 ['Inlet / nacelle lip',[[R*1.02,x(-.02)],[R*1.0,x(.0)],[R*.98,x(.12)]],'schematic',0x82B9FF,0],
 ['Fan (calc. tip/hub)',[[d.rhub,x(.12)],[R*.97,x(.12)],[R*.97,x(.16)],[d.rhub*1.1,x(.16)]],'calculated',0x35D6F2,1],
 ['Bypass duct casing',[[R,x(.16)],[R,x(.86)],[d.r19o,x(1.0)]],'calc. at fan/exit; length schematic',0x82B9FF,0],
 ['Compressor (not sized)',[[d.rcore,x(.18)],[d.rcore*.8,x(.4)],[d.rcore*.55,x(.46)]],'schematic; face radius calculated',0x5aa0d8,2],
 ['Combustor (not sized)',[[d.rcore*.62,x(.46)],[d.rcore*.62,x(.58)]],'schematic',0xF2B544,0],
 ['Turbine (not sized)',[[d.rcore*.62,x(.58)],[d.rcore*.78,x(.72)]],'schematic',0xD9534F,3],
 ['Core nozzle (calc. exit)',[[d.rcore*.78,x(.72)],[d.r9,x(.95)]],'exit radius calculated',0xEAF1F8,0]];
const parts=[], mats=[]; const rot={};
P.forEach((p,i)=>{const pts=p[1].map(q=>new THREE.Vector2(q[0],q[1])); const g=new THREE.LatheGeometry(pts,64);
 const m=new THREE.MeshStandardMaterial({color:p[3],metalness:.5,roughness:.45,side:THREE.DoubleSide,transparent:true,opacity:1,clippingPlanes:[]});
 const o=new THREE.Mesh(g,m); o.rotation.z=-Math.PI/2; o.userData={name:p[0],tag:p[2],i,rot:p[4]}; sc.add(o); parts.push(o); mats.push(m);
 if(p[4]){const mk=new THREE.Group(); for(let k=0;k<8;k++){const b=new THREE.Mesh(new THREE.BoxGeometry(R*.01,(p[1][1][0]-p[1][0][0])*.9,R*.01),new THREE.MeshBasicMaterial({color:0x080D16})); b.position.set(0,(p[1][1][0]+p[1][0][0])/2,0); const g2=new THREE.Group(); g2.add(b); g2.rotation.z=k*Math.PI/4; mk.add(g2);} mk.position.x=(p[1][0][1]+p[1][1][1])/2; mk.rotation.y=Math.PI/2; o.userData.mk=mk; sc.add(mk); mk.userData.base=mk.position.x;}});
// airflow particles (schematic streamlines, not CFD)
const N=240, pos=new Float32Array(N*3), info=[]; for(let i=0;i<N;i++){const byp=i%2; const r=byp?R*(.55+.4*Math.random()):d.rcore*.5*Math.random(); const a=Math.random()*6.283; info.push({r,a,byp,s:(byp?1.1:.7)*L*.004,x:Math.random()*L});}
const pg=new THREE.BufferGeometry(); pg.setAttribute('position',new THREE.BufferAttribute(pos,3)); const pts=new THREE.Points(pg,new THREE.PointsMaterial({size:R*.025,color:0x35D6F2})); sc.add(pts);
// afterburner plume
const pl=new THREE.Mesh(new THREE.ConeGeometry(d.r9*1.1,L*.35,24,1,true),new THREE.MeshBasicMaterial({color:0xF28C35,transparent:true,opacity:.55})); pl.rotation.z=Math.PI/2; pl.position.x=x(.95)+L*.17; sc.add(pl);
const st={exp:false,trans:false,sec:false,spin:true,flow:true,ab:d.wet,iso:-1}; const bar=document.getElementById('bar');
function btn(t,k){const b=document.createElement('button'); b.textContent=t; b.onclick=()=>{st[k]=!st[k]; b.classList.toggle('on',st[k])}; if(st[k])b.classList.add('on'); bar.appendChild(b)} 
[['Exploded','exp'],['Transparent','trans'],['Cross-section','sec'],['Rotation','spin'],['Airflow','flow'],['Afterburner','ab']].forEach(a=>btn(...a));
const sel=document.createElement('select'); sel.innerHTML='<option value="-1">All components</option>'+parts.map((p,i)=>'<option value="'+i+'">'+p.userData.name+'</option>').join(''); sel.onchange=()=>st.iso=+sel.value; bar.appendChild(sel);
const labels=parts.map(p=>{const e=document.createElement('div'); e.className='lb'; document.body.appendChild(e); return e});
document.getElementById('note').textContent='D_fan='+d.D.toFixed(3)+' m | A9='+d.A9.toFixed(3)+' m2 | A19='+d.A19.toFixed(3)+' m2 | core nozzle '+(d.choked?'choked':'unchoked')+' | ribs on rotors are rotation markers, NOT blades | lengths of un-sized parts are schematic';
function loop(){requestAnimationFrame(loop);
 parts.forEach((o,i)=>{const sh=st.exp?i*R*.35:0; o.position.x=sh; const hide=st.iso>=0&&st.iso!==i; o.visible=!hide; const m=o.material; m.opacity=st.trans?.25:1; m.clippingPlanes=st.sec?[plane]:[]; m.emissive.setHex(st.iso===i?0x113344:0);
  if(o.userData.rot&&st.spin)o.userData.mk&&(o.userData.mk.children.forEach(c=>c.rotation.z+=.02*(o.userData.rot==3?-1:1)*(1+.2*o.userData.rot))); if(o.userData.mk){o.userData.mk.position.x=o.userData.mk.userData.base+sh;o.userData.mk.visible=!hide}
  const e=labels[i]; const v=new THREE.Vector3((o.geometry.boundingBox||(o.geometry.computeBoundingBox(),o.geometry.boundingBox)).getCenter(new THREE.Vector3()).y+sh,0,0).project(cam); e.style.display=hide?'none':'block'; e.style.left=((v.x+1)/2*innerWidth)+'px'; e.style.top=((1-v.y)/2*innerHeight+ (i%2?24:-14))+'px'; e.textContent=o.userData.name+' ['+o.userData.tag+']';});
 pts.visible=st.flow; pl.visible=st.ab; pl.material.opacity=.45+.15*Math.sin(performance.now()/90);
 for(let i=0;i<N;i++){const q=info[i]; q.x+=q.s; if(q.x>L*(q.byp?1:.95))q.x=0; const lim=q.byp?1:Math.min(1,.5+q.x/L); pos[3*i]=q.x; pos[3*i+1]=q.r*Math.cos(q.a)*lim; pos[3*i+2]=q.r*Math.sin(q.a)*lim;} pg.attributes.position.needsUpdate=true;
 ctl.update(); rn.render(sc,cam);} loop();
</script>"""

def viewer_html(dims: dict) -> str:
    return _HTML.replace("__DIMS__", json.dumps(dims))
