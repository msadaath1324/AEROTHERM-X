"""T-s diagram data from solver stations (total states). s referenced to 288.15 K, 101325 Pa."""
from core import gas_properties as gp
import math
def _s(T, P): return gp.phi(T) - gp.phi(288.15) - gp.R_GAS * math.log(P / 101325.0)
def ts_data(res):
    st = res["stations_Tt_Pt"]; pts = lambda keys: [(k, _s(*st[k]), st[k][0]) for k in keys]
    core = pts(["t0", "2", "13", "3", "4", "45", "5"]); byp = pts(["t0", "2", "13"])
    return dict(core=[dict(station=k, s=s, T=T) for k, s, T in core], bypass=[dict(station=k, s=s, T=T) for k, s, T in byp])
