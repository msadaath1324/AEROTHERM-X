# AEROTHERM-X

**Preliminary Aerospace Propulsion Design & Analysis Environment**  
*A modular Python application for exploratory gas-turbine cycle analysis, preliminary sizing, performance estimation and design-space studies.*

> **Development status: Work in progress.** AEROTHERM-X is an educational and preliminary-analysis project. It is not a certified engine design tool, and its outputs must not be used as the sole basis for hardware design, safety decisions or flight operations.

---

## Overview

AEROTHERM-X brings several early-stage propulsion-engine calculations into one Streamlit application. Its current emphasis is a separate-flow, two-spool turbofan design-point model, supported by preliminary component sizing, nozzle calculations, parametric performance studies, optimization and engineering checks.

The project is intended to make assumptions visible, support repeatable design studies and provide a foundation for progressively higher-fidelity propulsion models.

## Current capabilities

| Area | Current implementation | Important qualification |
|---|---|---|
| Engine architecture | Heuristic architecture recommendation | A screening aid, not an optimality proof |
| Atmosphere | ISA atmosphere utility | Check its supported altitude range in source before extrapolating |
| Cycle analysis | Separate-flow, two-spool turbofan design-point solver | Uses simplified component and gas-property assumptions |
| Gas properties | Temperature-dependent property approximations | Combustion products are not fully composition-resolved |
| Nozzles | Convergent and convergent-divergent calculation paths | Simplified one-dimensional model; no detailed shock/boundary-layer solution |
| Preliminary sizing | Fan, core-face, turbomachinery and nozzle sizing utilities | Not detailed aerodynamic or structural design |
| Performance studies | Parameter sweeps, sensitivity and thrust-lapse estimates | Results inherit cycle-model assumptions |
| Mission estimate | Breguet range relation and required-thrust utility | Simplified mission-level estimate |
| Optimization | Differential-evolution design-space search and TSFC/diameter Pareto study | Constraint handling and feasibility checks should be independently reviewed |
| Visualization | Cycle plots and interactive 3D engine representation | Visualization is illustrative, not a validated CAD geometry |
| Reporting | PDF report generation | Report content is only as reliable as the underlying model |
| Benchmark script | CFM56-7B-inspired comparison case | Not an independently validated reproduction of manufacturer data |

## Application screenshots

Add screenshots from a locally running, tested application here. Recommended captures:

1. Main design-input page and engine summary.
2. Thermodynamic station table and cycle diagram.
3. Nozzle and component-sizing results.
4. Optimization results and validation panel.
5. 3D visualization and generated report.

Do not use screenshots containing placeholder, stale or unverified values as evidence of model validation.

## Repository structure

```text
AEROTHERM-X/
├── app.py                     # Streamlit application entry point
├── config.py                  # Application configuration and feature notes
├── requirements.txt           # Python dependencies
├── core/                      # Engineering calculations
│   ├── atmosphere.py           # Standard-atmosphere utility
│   ├── component_sizing.py     # Preliminary component sizing
│   ├── cycle_solver.py         # Turbofan design-point cycle solver
│   ├── engine_selector.py      # Heuristic architecture recommendation
│   ├── gas_properties.py       # Working-fluid property approximations
│   ├── mission.py              # Mission-level estimation utilities
│   ├── nozzle.py               # Nozzle calculations
│   ├── optimization.py         # Design-space optimization
│   ├── performance.py          # Sweeps, sensitivity and performance estimates
│   ├── scaling.py              # Geometric scaling utilities
│   └── validation.py           # Engineering sanity checks
├── visualization/              # Plots and 3D visualization
├── reports/                    # PDF report generation
├── benchmarks/                 # Reference-case scripts
├── tests/                      # Core calculation checks
├── ui/                         # UI styling
└── .streamlit/                 # Streamlit configuration
```

## Architecture

```mermaid
flowchart TD
    A[User inputs] --> B[Streamlit interface: app.py]
    B --> C[Engine architecture screening]
    B --> D[Core cycle solver]
    D --> E[Atmosphere and gas properties]
    D --> F[Compressor / combustor / turbine states]
    D --> G[Nozzle models]
    B --> H[Component sizing and performance studies]
    B --> I[Optimization]
    D --> J[Validation checks]
    H --> J
    I --> J
    B --> K[Plots and 3D visualization]
    B --> L[PDF report]
```

## Installation

### Requirements

- Python 3.10 or newer is recommended.
- `pip` and a virtual environment.
- A modern browser for the Streamlit interface.

### Windows PowerShell

```powershell
git clone https://github.com/<YOUR-USERNAME>/AEROTHERM-X.git
cd AEROTHERM-X
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

### Linux / macOS

```bash
git clone https://github.com/<YOUR-USERNAME>/AEROTHERM-X.git
cd AEROTHERM-X
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

Then open the local address printed by Streamlit, normally `http://localhost:8501`.

## Tests and benchmark script

Run the current core check script from the repository root:

```bash
python tests/test_core.py
```

Run the preliminary reference-case script:

```bash
python benchmarks/cfm56_7b.py
```

These scripts are useful development checks, not proof of model validation. Record the Python version, dependency versions, input conditions and expected tolerances when extending the test suite. The current test file is a script-style check rather than a comprehensive `pytest` suite.

## Modelling assumptions and limitations

The current software is a preliminary model. In particular:

- The principal cycle solver is a simplified design-point turbofan model.
- Working-fluid properties use approximations; fuel chemistry and combustion-product composition are not fully resolved.
- Component efficiencies and pressure losses are prescribed inputs or simplified assumptions, not derived from validated component maps.
- Turbine blade cooling and detailed cooling-flow allocation are not modelled.
- Compressor and turbine maps, surge margin, choke lines, map scaling and full off-design spool matching are not implemented.
- Any off-design or flight-envelope estimates based on corrected-state approximations must be treated as approximate.
- No detailed three-dimensional CFD, combustor design, blade-row aerodynamics, stress/fatigue analysis, thermal analysis, manufacturing constraints or certification analysis is performed.
- Nozzle calculations are simplified and do not resolve detailed shock-boundary-layer interaction or viscous losses.
- The 3D engine view is a conceptual visualization, not manufacturing geometry.
- Architecture recommendations are heuristic and do not replace a requirements-driven trade study.

The feature list and source code should be checked before relying on any particular calculation. A feature being present in the interface does not imply that it has been validated against experimental data.

## Validation roadmap

A credible validation programme should compare model outputs against traceable sources at clearly stated operating conditions. Suggested steps:

1. Unit-test atmosphere, thermodynamic relations, nozzle choking and energy balances independently.
2. Add dimensional/unit checks and explicit input-range validation.
3. Compare design-point outputs against published textbook examples and openly documented engine data, recording source, conditions and uncertainty.
4. Separate calibration cases from independent validation cases.
5. Add compressor and turbine maps before claiming reliable off-design performance.
6. Add combustion-product properties and cooling-flow treatment before higher-fidelity hot-section predictions.
7. Report residuals and error bands rather than presenting a single agreement percentage without context.

## Roadmap

- [ ] Expand automated unit and regression tests.
- [ ] Correctly enforce and report every optimization constraint in the final feasibility result.
- [ ] Validate fan tip speed using the calculated rotational speed and geometry.
- [ ] Add explicit unit handling and input-range checks.
- [ ] Add traceable benchmark datasets and validation reports.
- [ ] Investigate composition-dependent combustion-product properties.
- [ ] Add compressor and turbine component maps and off-design spool matching.
- [ ] Improve turbine cooling and bleed-flow modelling.
- [ ] Expand nozzle validation and loss modelling.
- [ ] Verify the complete Streamlit UI and 3D viewer across supported browsers.

## Technology stack

- Python
- Streamlit
- NumPy and SciPy
- Pandas
- Plotly
- ReportLab
- Three.js (loaded by the browser-side 3D viewer)

## Contributing

Issues and pull requests are welcome. For engineering changes, include:

- The governing equations and assumptions.
- Units for all inputs and outputs.
- A reference or derivation where applicable.
- Tests covering nominal, boundary and invalid-input cases.
- A note explaining whether the change affects model fidelity or only presentation.

## Author

**Mohammed Sadaath**  
Aerospace Engineering | AEROTHERM-X Project

## Disclaimer

AEROTHERM-X is provided for educational, research and preliminary engineering exploration. It is supplied without warranty. Users are responsible for independently verifying equations, assumptions, input data and results. It is not approved or certified for aircraft, propulsion hardware or operational use.
