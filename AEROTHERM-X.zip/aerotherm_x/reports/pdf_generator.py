"""ReportLab PDF report. All numbers are read from solver result dicts passed in."""
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak

def _tbl(rows, head):
    t = Table([head] + rows, repeatRows=1)
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#111A27")), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                           ("GRID", (0, 0), (-1, -1), .3, colors.grey), ("FONTSIZE", (0, 0), (-1, -1), 8)]))
    return t

def build_report(path, project, inputs: dict, res, fan, nozzles, validation, arch, sweep_note=""):
    ss = getSampleStyleSheet(); S = []
    foot = lambda c, d: (c.setFont("Helvetica", 8), c.drawRightString(550, 20, f"AEROTHERM-X — page {d.page}"))
    S += [Spacer(1, 200), Paragraph("AEROTHERM-X", ss["Title"]), Paragraph("Preliminary Engine Design Report", ss["Heading2"]),
          Paragraph(project, ss["Normal"]), Paragraph("Status: PRELIMINARY — not validated against experiment.", ss["Normal"]), PageBreak()]
    S += [Paragraph("1. Requirements and inputs", ss["Heading2"]), _tbl([[k, str(v)] for k, v in inputs.items()], ["Parameter", "Value"]),
          Paragraph("2. Architecture", ss["Heading2"]), Paragraph(f"{arch['recommended']} (alternatives: {', '.join(arch['alternatives'])}). {arch['uncertainty']}.", ss["Normal"]),
          Paragraph("3. Station results (total conditions)", ss["Heading2"]),
          _tbl([[k, f"{v[0]:.1f}", f"{v[1]:.0f}"] for k, v in res["stations_Tt_Pt"].items()], ["Station", "T [K]", "P [Pa]"]),
          Paragraph("4. Performance", ss["Heading2"]),
          _tbl([[n, f"{res[k]:.4g}"] for n, k in [("Net thrust [N]", "thrust_N"), ("TSFC [mg/N·s]", "tsfc_mg_per_Ns"), ("Total flow [kg/s]", "m_total"),
                ("Fuel flow [kg/s]", "m_fuel"), ("Thermal eff.", "eta_thermal"), ("Propulsive eff.", "eta_propulsive"), ("Overall eff.", "eta_overall")]], ["Quantity", "Value"]),
          Paragraph("5. Component dimensions", ss["Heading2"])]
    rows = [[k, f"{v['value']:.4g} {v['unit']}", v["equation"], v["confidence"]] for d in (fan, nozzles) for k, v in d.items() if isinstance(v, dict) and "equation" in v]
    S += [_tbl(rows, ["Item", "Value", "Equation", "Confidence"]), Paragraph("6. Validation", ss["Heading2"]),
          Paragraph(f"Status: {validation['status']}. {validation['why_not_green']}", ss["Normal"]),
          _tbl([[a, b, c] for a, b, c in validation["items"]], ["Check", "Result", "Detail"]),
          Paragraph("7. Assumptions and limitations", ss["Heading2"])]
    S += [Paragraph("• " + a, ss["Normal"]) for a in res["assumptions"]] + [Paragraph("• " + sweep_note, ss["Normal"])] if sweep_note else [Paragraph("• " + a, ss["Normal"]) for a in res["assumptions"]]
    S += [Paragraph("8. References", ss["Heading2"]), Paragraph("Standard Brayton-cycle and mean-line relations (e.g. Mattingly, Elements of Propulsion; Walsh & Fletcher, Gas Turbine Performance); ISA per ISO 2533. CFM56-7B benchmark sources are listed in benchmarks/cfm56_7b.py.", ss["Normal"])]
    SimpleDocTemplate(path, pagesize=A4).build(S, onFirstPage=foot, onLaterPages=foot)
    return path
