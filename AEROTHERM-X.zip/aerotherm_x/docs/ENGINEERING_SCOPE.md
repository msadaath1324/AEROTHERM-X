# Engineering scope and model credibility

## Intended use

AEROTHERM-X is intended for learning, preliminary sizing exercises and comparative design-space exploration. It is not a high-fidelity engine performance deck and is not a substitute for validated propulsion design software.

## Fidelity levels

| Level | Meaning in this project |
|---|---|
| Implemented | A calculation path exists in the source code. |
| Approximate | A simplified model is used; assumptions can materially affect the result. |
| Demonstration | A visualization or workflow illustrates a concept but is not a validated physical model. |
| Not implemented | The project does not currently provide the capability. |

## Important distinctions

- A design-point solver does not establish off-design engine operability.
- A numerical optimizer does not guarantee a physically feasible design unless all constraints are explicitly enforced and checked after optimization.
- A component-size estimate is not a detailed aerodynamic, structural or manufacturing design.
- A reference-engine-inspired input case is not a validated reproduction of that engine.
- A successful software test verifies the tested code path, not the physical accuracy of the model.

## Reporting recommendations

Every reported result should include input conditions, units, model assumptions, solver status and validation status. Comparisons with published data should identify the source and match operating conditions as closely as possible. Where exact matching is impossible, disclose the differences.
