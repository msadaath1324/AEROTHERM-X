# Development guide

## Local setup

Create and activate a virtual environment, then install dependencies:

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
```

## Run the application

```bash
streamlit run app.py
```

## Run current checks

```bash
python tests/test_core.py
python benchmarks/cfm56_7b.py
```

## Engineering change checklist

1. State the physical assumptions and operating range.
2. Use SI units internally and label units at interfaces.
3. Check limiting cases and invalid inputs.
4. Add a regression test for the new behaviour.
5. Compare with an independent analytical result or traceable reference when possible.
6. Update the README capability table and engineering limitations.
7. Do not label a model validated until independent validation evidence is documented.
