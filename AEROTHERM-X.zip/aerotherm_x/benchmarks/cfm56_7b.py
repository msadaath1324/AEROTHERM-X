"""Benchmark vs published CFM56-7B data. T4 is NOT published, so it is swept, not tuned to hit a target.
Refs: [A] Wolfram SystemModeler CFM567B27 model (from Wikipedia): SLS 121.43 kN, cruise TSFC 1.54e-5 kg/N/s
      [B] Purdue AAE CFM56 page: 737-600/700/800 variant BPR 5.6, OPR 32.3, fan dia 61 in, cruise thrust 5905 lbf
      [C] Course note (univ-blida): airflow 783 lbm/s at BPR 5.1 (7B27 column), max-climb thrust 5980 lbf @35kft, OPR 32.6
      [D] Leeham/Bjorn: 7B27 BPR 5.1, takeoff PR ~29;  [E] planefyi: ~0.545 lb/lbf/h cruise (=15.4 mg/N/s)"""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from core.cycle_solver import CycleInputs, solve_cycle
from core.component_sizing import size_fan
LB = 0.45359237; LBF = 4.4482216
print("== SLS 7B27: ref thrust 121.43 kN, BPR 5.1, OPR~29, airflow 783 lbm/s = %.0f kg/s, fan D 1.55 m" % (783 * LB))
for t4 in (1500, 1600, 1700):
    r = solve_cycle(CycleInputs(0, 0.0, 5.1, 1.6, 29 / 1.6, t4, thrust_N=121430))
    D = size_fan(r)["tip_diameter"]["value"]
    print(f"T4={t4}: m_total={r['m_total']:.0f} kg/s ({r['m_total']/(783*LB)-1:+.1%}), fan D={D:.2f} m ({D/1.549-1:+.1%}), TSFC={r['tsfc_mg_per_Ns']:.1f} mg/Ns")
print("== Cruise 35 kft M0.8: ref thrust %.1f kN, BPR 5.5, OPR~32, TSFC 15.4 mg/Ns" % (5905 * LBF / 1e3))
for t4 in (1350, 1450, 1550):
    r = solve_cycle(CycleInputs(10668, 0.8, 5.5, 1.7, 32 / 1.7, t4, thrust_N=5905 * LBF))
    print(f"T4={t4}: TSFC={r['tsfc_mg_per_Ns']:.1f} ({r['tsfc_mg_per_Ns']/15.4-1:+.1%}), eta_th={r['eta_thermal']:.3f}, eta_p={r['eta_propulsive']:.3f}")

print("== Cruise gap sensitivity (documented, NOT a tuned fit)")
print("Cruise BPR is higher than SLS BPR on real engines (source [Leeham]: Trent example 9 -> 11); scaled estimate 5.5*11/9 ~ 6.7")
for lab, k in [("default efficiencies", {}), ("optimistic efficiencies", dict(eta_fan=.92, eta_hpc=.90, eta_hpt=.92, eta_lpt=.93, pr_inlet=.995, eta_nozzle=.99, pr_b=.96, eta_mech=.995))]:
    for t4 in (1350, 1450):
        r = solve_cycle(CycleInputs(10668, 0.8, 6.7, 1.6, 20, t4, thrust_N=5905 * LBF, **k))
        print(f"{lab}, BPR 6.7, T4={t4}: TSFC={r['tsfc_mg_per_Ns']:.1f} ({r['tsfc_mg_per_Ns']/15.4-1:+.1%})")
