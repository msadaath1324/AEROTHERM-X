"""AEROTHERM-X Streamlit shell. UNTESTED in the authoring environment (Streamlit not installable there)."""
import pathlib, sys
import numpy as np, pandas as pd, streamlit as st
sys.path.insert(0, str(pathlib.Path(__file__).parent))
from config import PAGES, NOT_IMPLEMENTED, THRUST_TO_N, ALT_TO_M
from core.cycle_solver import CycleInputs, solve_cycle
from core.engine_selector import recommend
from core.component_sizing import size_fan, size_nozzles, size_core_face, size_turbomachinery, NOT_IMPLEMENTED as CS_NI
from core.performance import sweep, to_csv
from core.scaling import scale_geometric
from core.validation import validate
from visualization.engine_3d import build_dims, viewer_html
import streamlit.components.v1 as components
from core.optimization import optimise, pareto_tsfc_vs_diameter, BOUNDS
from reports.pdf_generator import build_report
import io, tempfile, json
from core.performance import lapse, sensitivity
from core.mission import breguet, required_thrust_per_engine
from visualization.cycle_diagrams import ts_data

st.set_page_config(page_title="AEROTHERM-X", layout="wide", initial_sidebar_state="collapsed")
st.markdown(f"<style>{(pathlib.Path(__file__).parent / 'ui' / 'theme.css').read_text()}</style>", unsafe_allow_html=True)
S = st.session_state
S.setdefault("page", "00"); S.setdefault("project", "Untitled design")
for k, v in dict(thrust=120.0, tunit="kN", alt=10668.0, aunit="m", mach=0.8, bpr=6.0, fpr=1.6, cpr=20.0, t4=1450.0, t7=2000.0, cd=False).items():
    S.setdefault(k, v)

@st.cache_data(show_spinner="Solving cycle…")
def solve(alt, mach, bpr, fpr, cpr, t4, thrust, t7, cd):
    return solve_cycle(CycleInputs(alt, mach, bpr, fpr, cpr, t4, thrust_N=thrust, t7=t7, cd_nozzles=cd))

@st.cache_data(show_spinner="Computing flight envelope…")
def envelope(alt, mach, bpr, fpr, cpr, t4, thrust, cd, amax, t4cap, thr):
    d = CycleInputs(alt, mach, bpr, fpr, cpr, t4, thrust_N=thrust, cd_nozzles=cd)
    return lapse(d, solve_cycle(d), list(np.linspace(0, amax, 13)), list(np.linspace(0, 0.9, 10)), t4cap, thr)

KEYS = ["thrust", "tunit", "alt", "aunit", "mach", "bpr", "fpr", "cpr", "t4", "t7", "cd", "project"]
def readout(items):
    st.markdown("<div class='readout'>" + "".join(f"<div><span>{n}</span><b>{v}</b></div>" for n, v in items) + "</div>", unsafe_allow_html=True)
def dark(f, **kw):
    f.update_layout(template="plotly_dark", paper_bgcolor="#080D16", plot_bgcolor="#111A27", margin=dict(l=50, r=20, t=30, b=40), **kw); return f

def current(wet=False):
    return solve(S.alt * ALT_TO_M[S.aunit], S.mach, S.bpr, S.fpr, S.cpr, S.t4, S.thrust * THRUST_TO_N[S.tunit], S.t7 if wet else None, S.cd)

def safe(fn):
    try: return fn()
    except ValueError as e: st.error(f"RED — calculation failed: {e}"); return None

names = dict(PAGES); names["00"] = "Home"
st.markdown(f"<style>.st-key-nav{S.page} button, .st-key-navhome button {{display:block}}.st-key-nav{S.page} button {{border-color:#35D6F2!important;color:#35D6F2!important;background:#0e2a38!important}}</style>" if S.page != "00" else "<style>.st-key-navhome button{border-color:#35D6F2!important;color:#35D6F2!important;background:#0e2a38!important}</style>", unsafe_allow_html=True)
arch = recommend(S.mach, S.bpr, False)["recommended"]
st.markdown(f"<div class='topbar'><b>AEROTHERM-X</b><span class='pill'>{S.project}</span><span>ARCH: {arch}</span>"
            f"<span class='amber'>STATUS: PRELIMINARY (AMBER)</span><span>UNITS: {S.tunit}/{S.aunit}</span><span>MODULE: <span class='crumb'>{S.page} {names.get(S.page, '')}</span></span></div>", unsafe_allow_html=True)
rail, main = st.columns([1, 14])
with rail:
    st.markdown("<div id='railmark'></div>", unsafe_allow_html=True)
    if st.button("⌂", help="Home", key="navhome"): S.page = "00"
    for n, name in PAGES:
        if st.button(n, help=name, key="nav" + n): S.page = n
with main:
    p = S.page
    if p == "00":
        st.markdown("# AEROTHERM-X\n**ADVANCED PROPULSION DESIGN & ANALYSIS ENVIRONMENT**")
        st.caption("From mission requirements to engine architecture, thermodynamic cycle and preliminary component design.")
        st.markdown("<div class='panel'>Calculation engine: available · Thermodynamic solver: design-point only · "
                    "Visualization: Plotly · 3D: <span class='ni'>NOT IMPLEMENTED</span> · Off-design: <span class='ni'>NOT IMPLEMENTED</span></div>", unsafe_allow_html=True)
        svg = ("<svg viewBox='0 0 900 260' style='width:100%;background:#0b1320;border:1px solid #1d2b3f'>"
               "<path d='M70 130 C70 62 130 48 210 50 L690 66 L820 108' fill='none' stroke='#82B9FF' stroke-width='2'/>"
               "<path d='M70 130 C70 198 130 212 210 210 L690 194 L820 152' fill='none' stroke='#82B9FF' stroke-width='2'/>"
               "<path d='M250 130 L420 116 L560 112 L700 104 L820 124 L820 136 L700 156 L560 148 L420 144Z' fill='#16263b' stroke='#35D6F2'/>"
               "<rect x='150' y='62' width='10' height='136' fill='#35D6F2'/><rect x='240' y='116' width='8' height='28' fill='#82B9FF'/>"
               "<g fill='none' stroke-width='1.6'><path class='flow' d='M5 78 H780' stroke='#82B9FF'/><path class='flow' d='M5 98 H760' stroke='#82B9FF'/>"
               "<path class='flow' d='M5 182 H760' stroke='#82B9FF'/><path class='flow' d='M5 162 H780' stroke='#82B9FF'/>"
               "<path class='flow slow' d='M5 120 H840' stroke='#35D6F2'/><path class='flow slow' d='M5 140 H840' stroke='#35D6F2'/></g>"
               "<text x='20' y='248' fill='#8CA0B8' font-size='11'>Illustrative turbofan schematic - not to scale, not driven by calculated data (see page 11 for the parametric model)</text></svg>")
        st.markdown(svg, unsafe_allow_html=True)
        S.project = st.text_input("Project name", S.project)
        c1, c2 = st.columns(2)
        if c1.button("CREATE NEW ENGINE DESIGN →"): S.page = "01"; st.rerun()
        c2.download_button("SAVE DESIGN (.json)", json.dumps({k: S[k] for k in KEYS}), f"{S.project}.json")
        up = st.file_uploader("OPEN EXISTING DESIGN (.json)", type="json")
        if up is not None and S.get("_loaded") != (up.name, up.size):
            try:
                data = json.load(up)
                for k in KEYS:
                    if k in data and type(data[k]) is type(S[k]): S[k] = data[k]
                S["_loaded"] = (up.name, up.size); st.rerun()
            except Exception as e: st.error(f"Invalid design file: {e}")
        if st.button("EXPLORE ENGINE ARCHITECTURES →"): S.page = "02"; st.rerun()
    elif p == "01":
        st.header("01 — Mission Definition")
        a, b = st.columns(2)
        S.thrust = a.number_input("Required thrust PER ENGINE (condition: the flight point below)", 1.0, 1e6, S.thrust)
        S.tunit = b.selectbox("Thrust unit", list(THRUST_TO_N), list(THRUST_TO_N).index(S.tunit))
        S.alt = a.number_input("Altitude", 0.0, 1e5, S.alt); S.aunit = b.selectbox("Altitude unit", list(ALT_TO_M), list(ALT_TO_M).index(S.aunit))
        S.mach = a.slider("Flight Mach", 0.0, 2.5, S.mach, 0.01); S.bpr = b.slider("Bypass ratio", 0.0, 15.0, S.bpr, 0.1)
        S.fpr = a.slider("Fan pressure ratio", 1.1, 3.5, S.fpr, 0.05); S.cpr = b.slider("Core compressor PR", 2.0, 40.0, S.cpr, 0.5)
        S.t4 = a.slider("Turbine inlet T4 [K]", 1000.0, 2000.0, S.t4, 10.0)
        S.cd = b.checkbox("Convergent-divergent nozzles (full expansion)", S.cd)
        if S.alt * ALT_TO_M[S.aunit] > 32000: st.warning("ISA implemented to 32 km only")
        if S.mach > 1.2 and S.bpr > 1.5: st.warning("High BPR is unrealistic for sustained supersonic flight (inputs not modified)")
        st.markdown("---")
        go_btn = st.button("CALCULATE ▶")
        r = safe(current)
        if r:
            readout([("Net thrust", f"{r['thrust_N']/1e3:.1f} kN"), ("TSFC", f"{r['tsfc_mg_per_Ns']:.2f} mg/N·s"), ("Total flow", f"{r['m_total']:.1f} kg/s"), ("Overall η", f"{r['eta_overall']:.3f}"), ("Gas-path energy residual", f"{r['checks']['energy_balance_rel']:.0e}")])
            st.caption("Results update live as inputs change (cached; recomputed only when an input changes). Station table: page 03.")
            if go_btn: S.page = "03"; st.rerun()
        st.caption("Pint-based unit handling: NOT IMPLEMENTED (simple fixed conversion tables used).")
    elif p == "02":
        st.header("02 — Engine Architecture")
        r = recommend(S.mach, S.bpr, st.checkbox("Afterburner required"))
        st.markdown(f"<div class='panel'><b>{r['recommended']}</b><br>Alternatives: {', '.join(r['alternatives'])}</div>", unsafe_allow_html=True)
        st.write(r["notes"]); st.caption(f"{r['uncertainty']}. Missing: {', '.join(r['missing_info'])}")
    elif p == "03":
        st.header("03 — Cycle Analysis")
        r = safe(current)
        if r:
            st.table(pd.DataFrame([(k, v[0], v[1]) for k, v in r["stations_Tt_Pt"].items()], columns=["Station", "T [K]", "P [Pa]"]))
            st.table(pd.DataFrame({"Quantity": ["Net thrust [N]", "TSFC [mg/N·s]", "Total flow [kg/s]", "Fuel flow [kg/s]", "η thermal", "η propulsive", "η overall"],
                "Value": [r["thrust_N"], r["tsfc_mg_per_Ns"], r["m_total"], r["m_fuel"], r["eta_thermal"], r["eta_propulsive"], r["eta_overall"]]}))
            import plotly.graph_objects as go
            d = ts_data(r); f = go.Figure()
            for nm, key in (("Core", "core"), ("Bypass", "bypass")):
                f.add_trace(go.Scatter(x=[q["s"] for q in d[key]], y=[q["T"] for q in d[key]], mode="lines+markers+text", text=[q["station"] for q in d[key]], textposition="top center", name=nm))
            st.plotly_chart(dark(f, xaxis_title="s − s_ref [J/kg·K] (total states; ref 288.15 K, 101325 Pa)", yaxis_title="Total temperature [K]", title="T–s diagram from solver stations"), use_container_width=True)
            st.caption("Assumptions: " + "; ".join(r["assumptions"]))
    elif p == "05":
        st.header("05 — Component Design")
        r = safe(current)
        if r:
            for k, v in {**size_fan(r), **size_nozzles(r)}.items():
                if isinstance(v, dict) and "equation" in v:
                    with st.expander(f"{k}: {v['value']:.4g} {v['unit']}  [{v['confidence']}]"):
                        st.write(f"Equation: {v['equation']}  \nInputs: {v['inputs']}  \nAssumptions: {v['assumptions']}")
                else: st.write(k, v)
            for k, v in size_turbomachinery(r).items():
                if isinstance(v, dict):
                    with st.expander(f"{k}: {v['value']} {v['unit']}  [{v['confidence']}]"): st.write(f"{v['equation']} — {v['assumptions']}")
                else: st.markdown(f"{k}: <span class='ni'>{v}</span>", unsafe_allow_html=True)
            for k, v in CS_NI.items(): st.markdown(f"{k}: <span class='ni'>{v}</span>", unsafe_allow_html=True)
    elif p == "06":
        st.header("06 — Afterburner")
        S.t7 = st.slider("Afterburner exit T7 [K]", 1500.0, 2300.0, S.t7, 10.0)
        d, w = safe(current), safe(lambda: current(True))
        if d and w:
            st.table(pd.DataFrame({"": ["Specific thrust [N·s/kg total]", "TSFC [mg/N·s]", "Fuel flow [kg/s]", "Core nozzle area [m²]"],
                "Dry": [d["specific_thrust_N_per_kgs"], d["tsfc_mg_per_Ns"], d["m_fuel"], d["A9_m2"]],
                "Wet": [w["specific_thrust_N_per_kgs"], w["tsfc_mg_per_Ns"], w["m_fuel"], w["A9_m2"]]}))
            st.caption("Afterburner acts on the core stream only; flame-holder/thermal-load sizing: NOT IMPLEMENTED.")
    elif p == "07":
        st.header("07 — Scaling Laboratory")
        ref = st.number_input("Reference thrust [N]", value=121430.0); dia = st.number_input("Reference fan diameter [m]", value=1.55)
        rpm = st.number_input("Reference fan rpm", value=5380.0); mass = st.number_input("Reference dry mass [kg] (enter your own)", value=2366.0)
        new = st.number_input("New thrust [N]", value=60000.0); k = st.slider("Mass exponent k (assumption)", 2.0, 3.0, 2.5, 0.1)
        s = scale_geometric(ref, dia, rpm, mass, new, k); st.json({a: b for a, b in s.items()})
    elif p == "08":
        st.header("08 — Performance Maps")
        import plotly.graph_objects as go
        prm = st.selectbox("Sweep parameter", ["mach", "bpr", "fpr", "t4", "alt_m"])
        lo, hi = st.slider("Range", 0.0, 2000.0 if prm == "t4" else 12000.0 if prm == "alt_m" else 3.0 if prm == "mach" else 15.0, (0.3, 0.9) if prm == "mach" else (1000.0, 1800.0) if prm == "t4" else (0.0, 11000.0) if prm == "alt_m" else (1.2, 12.0))
        base = CycleInputs(S.alt * ALT_TO_M[S.aunit], S.mach, S.bpr, S.fpr, S.cpr, S.t4, thrust_N=S.thrust * THRUST_TO_N[S.tunit], cd_nozzles=S.cd)
        df = pd.DataFrame(sweep(base, prm, np.linspace(lo, hi, 25)))
        ok = df[df.status == "ok"]
        for y, lab in [("thrust_N", "Net thrust [N]"), ("tsfc_mg_per_Ns", "TSFC [mg/N·s]")]:
            f = go.Figure(go.Scatter(x=ok[prm], y=ok[y], mode="lines+markers")); f.update_layout(template="plotly_dark", paper_bgcolor="#080D16", plot_bgcolor="#111A27", xaxis_title=prm, yaxis_title=lab)
            st.plotly_chart(f, use_container_width=True)
        st.caption(f"{len(df) - len(ok)} infeasible points omitted from plots (kept in CSV). Sweeps are re-designed cycles, not fixed-geometry off-design.")
        st.download_button("Download CSV", to_csv(df.to_dict("records")), "sweep.csv")
    elif p == "10":
        st.header("10 — Engineering Validation")
        r = safe(current)
        if r:
            v = validate(r, size_fan(r)); st.markdown(f"**STATUS: <span class='amber'>{v['status']}</span>** — {v['why_not_green']}", unsafe_allow_html=True)
            st.table(pd.DataFrame(v["items"], columns=["Check", "Result", "Detail"]))
    elif p == "04":
        st.header("04 — Engine Geometry")
        r = safe(current)
        if r:
            d = build_dims(r, size_fan(r), size_core_face(r)); sc = 300 / d["R"]
            c = lambda v: f"{150 + v * sc:.0f}"
            svg = (f"<svg viewBox='0 0 900 340' style='background:#111A27;width:100%'>"
                   f"<rect x='20' y='{150-d['R']*sc*0.5:.0f}' width='0' height='0'/>"
                   f"<path d='M40 170 L40 {170-d['R']*sc*0.5:.0f} L820 {170-d['r19o']*sc*0.5:.0f} L820 {170-d['r9']*sc*0.5:.0f}' fill='none' stroke='#82B9FF'/>"
                   f"<path d='M40 170 L40 {170+d['R']*sc*0.5:.0f} L820 {170+d['r19o']*sc*0.5:.0f} L820 {170+d['r9']*sc*0.5:.0f}' fill='none' stroke='#82B9FF'/>"
                   f"<rect x='120' y='{170-d['rhub']*sc*0.5:.0f}' width='14' height='{2*d['rhub']*sc*0.5:.0f}' fill='#35D6F2'/>"
                   f"<line x1='40' y1='170' x2='820' y2='170' stroke='#2a3b52' stroke-dasharray='4'/>"
                   f"<text x='30' y='330' fill='#8CA0B8' font-size='11'>Half-section schematic: radii at fan/core-face/nozzle exit calculated; axial layout schematic</text></svg>")
            st.markdown(svg, unsafe_allow_html=True)
            st.table(pd.DataFrame({"Dimension": ["Fan tip dia [m]", "Fan hub dia [m]", "Core-face dia [m] (assumed Mach/hub-tip)", "Core nozzle exit dia [m]", "Bypass nozzle area [m²]"],
                "Value": [d["D"], 2 * d["rhub"], 2 * d["rcore"], 2 * d["r9"], d["A19"]]}))
    elif p == "09":
        st.header("09 — Optimization")
        obj = st.selectbox("Objective", ["tsfc", "eta_overall", "frontal_area"])
        a, b, c = st.columns(3); dmax = a.number_input("Max fan diameter [m]", 0.5, 8.0, 3.0); opr = b.number_input("Max OPR", 5.0, 80.0, 50.0); t4m = c.number_input("Max T4 [K]", 1100.0, 2200.0, 1700.0)
        base = CycleInputs(S.alt * ALT_TO_M[S.aunit], S.mach, S.bpr, S.fpr, S.cpr, S.t4, thrust_N=S.thrust * THRUST_TO_N[S.tunit], cd_nozzles=S.cd)
        if st.button("RUN OPTIMISATION"):
            with st.spinner("Differential evolution…"):
                o = optimise(base, obj, opr, dmax, t4m)
            st.success("Feasible optimum" if o["feasible"] else "RED — no feasible optimum found within constraints")
            st.table(pd.DataFrame({"Variable": list(BOUNDS), "Initial": [S.bpr, S.fpr, S.cpr, S.t4], "Optimised": list(o["x"].values()), "Bounds": [str(v) for v in BOUNDS.values()]}))
            import plotly.graph_objects as go
            f = go.Figure(go.Scatter(y=o["history"], mode="lines")); f.update_layout(template="plotly_dark", paper_bgcolor="#080D16", plot_bgcolor="#111A27", xaxis_title="generation", yaxis_title="penalised objective"); st.plotly_chart(f, use_container_width=True)
            st.caption("Optimum at a bound (e.g. BPR=15) means the model lacks a counter-penalty (nacelle drag/weight are NOT modelled). Mass objective: NOT IMPLEMENTED.")
        if st.checkbox("Pareto: TSFC vs fan diameter"):
            pf = pareto_tsfc_vs_diameter(base, np.linspace(1.5, 4.0, 6), opr_max=opr, t4_max=t4m)
            if pf:
                import plotly.graph_objects as go
                f = go.Figure(go.Scatter(x=[q["d_cap"] for q in pf], y=[q["tsfc"] for q in pf], mode="lines+markers")); f.update_layout(template="plotly_dark", paper_bgcolor="#080D16", plot_bgcolor="#111A27", xaxis_title="fan diameter cap [m]", yaxis_title="TSFC [mg/N·s]"); st.plotly_chart(f, use_container_width=True)
            else: st.warning("No feasible points")
    elif p == "12":
        st.header("12 — Design Reports")
        r = safe(current)
        if r and st.button("GENERATE PDF"):
            f = size_fan(r); tmp = tempfile.NamedTemporaryFile(suffix=".pdf", delete=False).name
            build_report(tmp, S.project, dict(thrust=f"{S.thrust} {S.tunit}", altitude=f"{S.alt} {S.aunit}", mach=S.mach, BPR=S.bpr, FPR=S.fpr, CPR=S.cpr, T4=S.t4), r, f, size_nozzles(r), validate(r, f), recommend(S.mach, S.bpr, False))
            st.download_button("Download report", open(tmp, "rb").read(), "aerotherm_x_report.pdf")
    elif p == "13":
        st.header("13 — Flight Envelope (fixed-size engine)")
        import plotly.graph_objects as go
        a1, a2, a3 = st.columns(3)
        t4cap = a1.number_input("T4 flat-rating cap [K]", 1000.0, 2200.0, max(S.t4, 1700.0)); thr = a2.slider("Throttle (fraction of constant-θ T4)", 0.7, 1.0, 1.0, 0.01); amax = a3.number_input("Max altitude [m]", 2000.0, 20000.0, 12000.0)
        rows = safe(lambda: envelope(S.alt * ALT_TO_M[S.aunit], S.mach, S.bpr, S.fpr, S.cpr, S.t4, S.thrust * THRUST_TO_N[S.tunit], S.cd, amax, t4cap, thr))
        if rows:
            df = pd.DataFrame(rows); ok = df[df.status == "ok"]
            for col, lab, div in (("thrust_N", "Net thrust [kN]", 1e3), ("tsfc_mg_per_Ns", "TSFC [mg/N·s]", 1.0)):
                z = ok.pivot(index="alt_m", columns="mach", values=col) / div
                f = go.Figure(go.Contour(z=z.values, x=z.columns, y=z.index, colorbar=dict(title=lab), contours=dict(showlabels=True)))
                f.add_trace(go.Scatter(x=[S.mach], y=[S.alt * ALT_TO_M[S.aunit]], mode="markers", marker=dict(size=11, color="#F2B544"), name="design point"))
                st.plotly_chart(dark(f, xaxis_title="Mach", yaxis_title="Altitude [m]", title=lab), use_container_width=True)
            st.caption(f"{len(df) - len(ok)} infeasible points omitted. Constant-corrected-state approximation: corrected flow fixed, PRs/efficiencies fixed at design values; component maps, spool matching and nozzle scheduling NOT IMPLEMENTED. Treat as first-order lapse, not engine-deck accuracy.")
            st.download_button("Download CSV", pd.DataFrame(rows).to_csv(index=False), "envelope.csv")
    elif p == "14":
        st.header("14 — Mission Range (Breguet)")
        r = safe(current)
        if r:
            a1, a2, a3, a4 = st.columns(4)
            n = a1.number_input("Engines", 1, 8, 2); w0 = a2.number_input("Start-of-cruise mass [kg]", 1000.0, 1e6, 70000.0); fuel = a3.number_input("Cruise fuel [kg]", 1.0, 5e5, 8000.0); ld = a4.number_input("Cruise L/D (your assumption)", 3.0, 30.0, 17.0)
            try:
                b = breguet(r["V0"], r["tsfc_mg_per_Ns"] * 1e-6, ld, w0, w0 - fuel)
                need = required_thrust_per_engine(w0 - fuel / 2, ld, n)
                readout([("Cruise speed", f"{r['V0']:.0f} m/s"), ("Range", f"{b['range_m']/1e3:.0f} km"), ("Endurance", f"{b['endurance_s']/3600:.2f} h"), ("Thrust needed / engine", f"{need/1e3:.1f} kN"), ("Thrust available (design)", f"{r['thrust_N']/1e3:.1f} kN")])
                if need > r["thrust_N"]: st.error("RED — required cruise thrust exceeds the thrust of this design point; weight/L/D combination not sustainable")
                else: st.info(f"Design point thrust is {r['thrust_N']/need:.2f}× the mean cruise requirement (engine would run throttled back, outside this design-point TSFC).")
            except ValueError as e: st.error(str(e))
            st.caption("Constant speed, L/D and TSFC; uninstalled TSFC (no installation losses, no climb/descent/reserves). L/D and weights are your inputs.")
    elif p == "15":
        st.header("15 — Sensitivity Analysis")
        import plotly.graph_objects as go
        base = CycleInputs(S.alt * ALT_TO_M[S.aunit], S.mach, S.bpr, S.fpr, S.cpr, S.t4, thrust_N=S.thrust * THRUST_TO_N[S.tunit], cd_nozzles=S.cd)
        rows = safe(lambda: sensitivity(base))
        if rows:
            df = pd.DataFrame(rows); f = go.Figure()
            f.add_trace(go.Bar(y=df.param, x=df.tsfc, orientation="h", name="TSFC")); f.add_trace(go.Bar(y=df.param, x=df.specific_thrust, orientation="h", name="Specific thrust"))
            st.plotly_chart(dark(f, barmode="group", xaxis_title="elasticity d(ln y)/d(ln x)"), use_container_width=True)
            st.table(df)
            st.caption("1 % finite-difference elasticities at fixed required thrust (efficiencies perturbed downward). Local to this design point.")
    elif p == "11":
        st.header("11 — 3D Engine Assembly")
        wet = st.checkbox("Afterburner ON (uses T7 from page 06)")
        r = safe(lambda: current(wet))
        if r:
            components.html(viewer_html(build_dims(r, size_fan(r), size_core_face(r), wet)), height=640)
            st.caption("Fan, core-face and nozzle-exit dimensions come from the solver; compressor/combustor/turbine lengths and inner profiles are schematic (labelled in the view). Airflow particles are illustrative, not CFD. Loads Three.js from jsDelivr (needs internet).")
    else:
        name = dict(PAGES).get(p, p)
        st.header(f"{p} — {name}")
        st.markdown("<span class='ni'>NOT IMPLEMENTED</span>", unsafe_allow_html=True)
