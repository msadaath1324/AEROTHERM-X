PAGES = [("01", "Mission Definition"), ("02", "Engine Architecture"), ("03", "Cycle Analysis"),
         ("04", "Engine Geometry"), ("05", "Component Design"), ("06", "Afterburner"),
         ("07", "Scaling Laboratory"), ("08", "Performance Maps"), ("09", "Optimization"),
         ("10", "Engineering Validation"), ("11", "3D Engine Assembly"), ("12", "Design Reports"),
         ("13", "Flight Envelope"), ("14", "Mission Range"), ("15", "Sensitivity")]
NOT_IMPLEMENTED = set()
THRUST_TO_N = {"N": 1.0, "kN": 1e3, "lbf": 4.4482216}
ALT_TO_M = {"m": 1.0, "km": 1e3, "ft": 0.3048}
