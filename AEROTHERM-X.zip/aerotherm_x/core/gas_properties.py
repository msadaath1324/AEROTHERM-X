"""Temperature-dependent ideal-gas model (air).
ASSUMPTION: cp(T) is interpolated from approximate tabulated dry-air values
(textbook tables, ~±1 %). Hot-section gas is modelled as air (fuel mass added
in the mass balance only). Cantera-based products are NOT IMPLEMENTED yet."""
import numpy as np
R_GAS = 287.05
_T = np.array([200, 250, 300, 400, 500, 600, 700, 800, 900, 1000, 1200, 1400, 1600, 1800, 2000.])
_CP = 1e3 * np.array([1.007, 1.006, 1.005, 1.013, 1.029, 1.051, 1.075, 1.099, 1.121, 1.142,
                      1.175, 1.207, 1.230, 1.248, 1.264])
_G = np.arange(150.0, 2501.0, 1.0)
_CPG = np.interp(_G, _T, _CP)
_H = np.concatenate(([0.0], np.cumsum(0.5 * (_CPG[1:] + _CPG[:-1]))))            # J/kg (ref 150 K)
_PHI = np.concatenate(([0.0], np.cumsum(0.5 * (_CPG[1:] / _G[1:] + _CPG[:-1] / _G[:-1]))))  # J/kg/K

def cp(T): return float(np.interp(T, _G, _CPG))
def h(T): return float(np.interp(T, _G, _H))
def phi(T): return float(np.interp(T, _G, _PHI))
def T_from_h(x): return float(np.interp(x, _H, _G))
def T_from_phi(x): return float(np.interp(x, _PHI, _G))
def gamma(T): c = cp(T); return c / (c - R_GAS)
