"""Engine scaling. Only relations that follow from the cycle are implemented.
Geometric similarity at fixed cycle: mass flow ~ L^2 (corrected flow ~ area), thrust ~ L^2 at same
specific thrust, tip speed fixed => rpm ~ 1/L. Mass ~ L^3 is a GEOMETRIC upper-bound idealisation
(real engine mass scaling is weaker because wall thickness and fixed hardware do not scale):
shown with a user-visible exponent. Reynolds, material, stress and efficiency effects: NOT IMPLEMENTED."""
import math

def scale_geometric(thrust_ref_N, diameter_ref_m, rpm_ref, mass_ref_kg, thrust_new_N, mass_exponent=2.5):
    k_area = thrust_new_N / thrust_ref_N          # same specific thrust -> area ratio
    L = math.sqrt(k_area)                          # linear scale
    return dict(length_scale=L, diameter_m=diameter_ref_m * L, rpm=rpm_ref / L,
                mass_kg=mass_ref_kg * L ** mass_exponent,
                assumptions=f"same cycle & tip speed; mass ~ L^{mass_exponent} (user-set, not derived)",
                tip_speed_ratio=1.0, reynolds_note="Re ~ L at fixed speed: small engines lose efficiency (NOT MODELLED)")

def corrected_flow(m, Tt, Pt, Tref=288.15, Pref=101325.0):
    return m * math.sqrt(Tt / Tref) / (Pt / Pref)

def corrected_speed(N, Tt, Tref=288.15):
    return N / math.sqrt(Tt / Tref)
