"""Preliminary sizing from cycle results. Only fan annulus and nozzles are implemented;
every other component returns NOT IMPLEMENTED with the missing inputs named."""
import math
from . import gas_properties as gp

def mass_flow_param(M, g):
    """m*sqrt(Tt)/(A*Pt) for ideal gas [sqrt(K)*s/m]."""
    return math.sqrt(g / gp.R_GAS) * M * (1 + (g - 1) / 2 * M**2) ** (-(g + 1) / (2 * (g - 1)))

def size_fan(res, M_face=0.60, hub_tip=0.30, u_tip=400.0):
    Tt, Pt = res["stations_Tt_Pt"]["2"]
    g = gp.gamma(Tt)
    A = res["m_total"] * math.sqrt(Tt) / (Pt * mass_flow_param(M_face, g))
    D = math.sqrt(4 * A / (math.pi * (1 - hub_tip**2)))
    rpm = u_tip / (D / 2) * 60 / (2 * math.pi)
    inp = "m_total, Tt2, Pt2, gamma(Tt2)"
    asm = f"face Mach {M_face}, hub/tip {hub_tip}, tip speed {u_tip} m/s (design choices, not derived)"
    mk = lambda v, u, eq, conf: dict(value=v, unit=u, equation=eq, inputs=inp, assumptions=asm, confidence=conf)
    return {"annulus_area": mk(A, "m2", "A = m*sqrt(Tt)/(Pt*MFP(M))", "medium"),
            "tip_diameter": mk(D, "m", "A = pi/4*D^2*(1-(rh/rt)^2)", "medium"),
            "hub_diameter": mk(D * hub_tip, "m", "D_hub = D*(rh/rt)", "medium"),
            "rotational_speed": mk(rpm, "rpm", "N = U_tip/r_tip", "low"),
            "blade_count": "NOT IMPLEMENTED (needs solidity/loading correlation)"}

def size_nozzles(res):
    mk = lambda n: dict(value=res[n], unit="m2", equation="A = m/(rho*V) at exit (convergent: exit = throat)",
                        inputs="m, Pe, Te, V from nozzle solver", assumptions="convergent nozzle, Cv=0.98", confidence="medium")
    out = {"core_nozzle_area": mk("A9_m2"), "bypass_nozzle_area": mk("A19_m2"),
            "core_choked": res["core_nozzle"]["choked"], "bypass_choked": res["bypass_nozzle"]["choked"],
            "variable_area_note": "wet operation needs larger A9 than dry at same mass flow" if res["afterburning"] else ""}
    if res["cd_nozzles"]:
        for k, n in (("core_throat_area", "A9_throat_m2"), ("bypass_throat_area", "A19_throat_m2")):
            out[k] = dict(value=res[n], unit="m2", equation="A* = m/(rho* V*) at M=1", inputs="m, throat state from choke solve",
                          assumptions="lumped nozzle efficiency; exit areas above are full-expansion", confidence="medium")
    return out

NOT_IMPLEMENTED = {k: "NOT IMPLEMENTED" for k in ["compressor", "combustor", "turbine", "inlet"]}

def size_core_face(res, M_face=0.45, hub_tip=0.60):
    """Core annulus at HPC face (station 13 conditions; booster/transition duct ignored). Design Mach and hub/tip are ASSUMED."""
    Tt, Pt = res["stations_Tt_Pt"]["13"]
    A = res["m_core"] * math.sqrt(Tt) / (Pt * mass_flow_param(M_face, gp.gamma(Tt)))
    return dict(annulus_area=A, tip_diameter=math.sqrt(4 * A / (math.pi * (1 - hub_tip**2))), hub_tip=hub_tip,
                assumptions=f"face Mach {M_face}, hub/tip {hub_tip} assumed; confidence low")

def size_turbomachinery(res, u_mean_c=350.0, psi_c=0.35, u_mean_t=400.0, psi_t=1.4):
    """Mean-line STAGE-COUNT estimates only: n = ceil(w / (psi * U^2)). U and psi are ASSUMED design values (confidence low)."""
    st = res["stations_Tt_Pt"]; w_hpc = gp.h(st["3"][0]) - gp.h(st["13"][0])
    w_hpt = gp.h(st["4"][0]) - gp.h(st["45"][0]); w_lpt = gp.h(st["45"][0]) - gp.h(st["5"][0])
    mk = lambda n, eq: dict(value=n, unit="stages", equation=eq, inputs="specific work from cycle",
                            assumptions=f"U_c={u_mean_c}, psi_c={psi_c}, U_t={u_mean_t}, psi_t={psi_t} (assumed)", confidence="low")
    return {"hpc_stages": mk(math.ceil(w_hpc / (psi_c * u_mean_c**2)), "n=ceil(dh0/(psi U^2))"),
            "hpt_stages": mk(max(1, math.ceil(w_hpt * (1 + res["f"]) / (psi_t * u_mean_t**2))), "n=ceil(dh0/(psi U^2))"),
            "lpt_stages": mk(max(1, math.ceil(w_lpt * (1 + res["f"]) / (psi_t * u_mean_t**2))), "n=ceil(dh0/(psi U^2))"),
            "turbine_cooling": "NOT IMPLEMENTED (T4 above ~1400 K needs cooling flow; not modelled)"}
