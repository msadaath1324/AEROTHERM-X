"""Convergent nozzle with variable gamma, isentropic-efficiency losses and choking."""
import math
from scipy.optimize import brentq
from . import gas_properties as gp

def _expand(Tt, Pt, Pe, eta):
    Ts = gp.T_from_phi(gp.phi(Tt) - gp.R_GAS * math.log(Pt / Pe))
    dh = eta * (gp.h(Tt) - gp.h(Ts))
    Te = gp.T_from_h(gp.h(Tt) - dh)
    return math.sqrt(2 * dh), Te

def convergent_nozzle(Tt, Pt, P0, eta=0.98):
    """Returns dict: V, Pe, Te, rho, mach, choked, area_per_kgs, pressure_thrust_per_kgs."""
    if Pt <= P0:
        raise ValueError("Nozzle total pressure <= ambient: no thrust possible")
    a = lambda Te: math.sqrt(gp.gamma(Te) * gp.R_GAS * Te)
    V, Te = _expand(Tt, Pt, P0, eta)
    choked = V > a(Te)
    Pe = P0
    if choked:
        Pe = brentq(lambda p: (lambda v_t: v_t[0] - a(v_t[1]))(_expand(Tt, Pt, p, eta)),
                    P0, Pt * (1 - 1e-9))
        V, Te = _expand(Tt, Pt, Pe, eta)
    rho = Pe / (gp.R_GAS * Te)
    return dict(V=V, Pe=Pe, Te=Te, rho=rho, mach=V / a(Te), choked=choked,
                area_per_kgs=1 / (rho * V), pressure_thrust_per_kgs=(Pe - P0) / (rho * V))


def cd_nozzle(Tt, Pt, P0, eta=0.98, eta_div=0.995):
    """Convergent-divergent nozzle, divergent section sized for full expansion to ambient (adapted).
    Convergent part = same model as convergent_nozzle (efficiency eta, throat M=1). Divergent part: expansion of the
    throat STATIC state to P0 with isentropic efficiency eta_div (ASSUMED 0.995) and energy conservation
    V_e^2 = V_th^2 + 2*dh. Boundary-layer, divergence-angle and shock effects are NOT modelled."""
    th = convergent_nozzle(Tt, Pt, P0, eta)
    if not th["choked"]:
        return {**th, "A_throat_per_kgs": th["area_per_kgs"], "A_exit_per_kgs": th["area_per_kgs"]}
    Ts = gp.T_from_phi(gp.phi(th["Te"]) + gp.R_GAS * math.log(P0 / th["Pe"]))
    dh = eta_div * (gp.h(th["Te"]) - gp.h(Ts)); Te = gp.T_from_h(gp.h(th["Te"]) - dh)
    V = math.sqrt(th["V"] ** 2 + 2 * dh); rho = P0 / (gp.R_GAS * Te)
    return dict(V=V, Pe=P0, Te=Te, rho=rho, mach=V / math.sqrt(gp.gamma(Te) * gp.R_GAS * Te), choked=True,
                area_per_kgs=1 / (rho * V), pressure_thrust_per_kgs=0.0,
                A_throat_per_kgs=th["area_per_kgs"], A_exit_per_kgs=1 / (rho * V))
