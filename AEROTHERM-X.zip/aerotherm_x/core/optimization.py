"""SciPy differential-evolution optimiser over (BPR, FPR, CPR, T4) at a fixed flight point and thrust.
Constraints are enforced by penalty; infeasible cycles get a large penalty (never silently accepted).
Mass objective: NOT IMPLEMENTED (no validated mass model) -> fan diameter is used as frontal-area proxy."""
from dataclasses import replace
import numpy as np
from scipy.optimize import differential_evolution
from .cycle_solver import CycleInputs, solve_cycle
from .component_sizing import size_fan

BOUNDS = {"bpr": (0.0, 15.0), "fpr": (1.1, 3.0), "cpr": (4.0, 40.0), "t4": (1100.0, 1900.0)}
OBJECTIVES = {"tsfc": lambda r, f: r["tsfc_mg_per_Ns"], "eta_overall": lambda r, f: -r["eta_overall"],
              "frontal_area": lambda r, f: f["tip_diameter"]["value"] ** 2}

def _eval(x, base, obj, opr_max, d_max, t4_max):
    c = replace(base, bpr=x[0], fpr=x[1], cpr=x[2], t4=x[3])
    try:
        r = solve_cycle(c); f = size_fan(r)
    except (ValueError, KeyError):
        return 1e6, None, None
    pen = 0.0
    if c.fpr * c.cpr > opr_max: pen += 1e3 * (c.fpr * c.cpr / opr_max - 1)
    if f["tip_diameter"]["value"] > d_max: pen += 1e3 * (f["tip_diameter"]["value"] / d_max - 1)
    if c.t4 > t4_max: pen += 1e3 * (c.t4 / t4_max - 1)
    return OBJECTIVES[obj](r, f) + pen, r, f

def optimise(base: CycleInputs, objective="tsfc", opr_max=50.0, d_max=5.0, t4_max=1800.0, seed=0, maxiter=40):
    hist = []
    fun = lambda x: _eval(x, base, objective, opr_max, d_max, t4_max)[0]
    res = differential_evolution(fun, list(BOUNDS.values()), seed=seed, maxiter=maxiter, popsize=10, tol=1e-6,
                                 polish=False, callback=lambda xk, convergence=None: hist.append(fun(xk)))
    val, r, f = _eval(res.x, base, objective, opr_max, d_max, t4_max)
    return dict(x=dict(zip(BOUNDS, res.x)), objective=objective, value=val, feasible=val < 1e5 and r is not None and
                res.x[1] * res.x[2] <= opr_max * 1.0001 and f["tip_diameter"]["value"] <= d_max * 1.0001,
                history=hist, result=r, evals=res.nfev, constraints=dict(opr_max=opr_max, d_max=d_max, t4_max=t4_max))

def pareto_tsfc_vs_diameter(base, d_caps, **kw):
    """Epsilon-constraint front: min TSFC subject to fan diameter <= cap."""
    out = []
    for cap in d_caps:
        o = optimise(base, "tsfc", d_max=cap, maxiter=25, **kw)
        if o["feasible"]: out.append(dict(d_cap=cap, tsfc=o["result"]["tsfc_mg_per_Ns"], **o["x"]))
    return out
