"""Design-point separate-flow two-spool turbofan (station-based, per unit core flow).
Station numbering: 0 freestream, 2 fan face, 13 fan exit, 25 HPC face, 3 HPC exit,
4 turbine inlet, 45 HPT exit, 5 LPT exit, 9 core nozzle, 19 bypass nozzle.
Simplifications (reported in result['assumptions']): no turbine cooling bleed,
core and bypass share the same fan PR/efficiency, hot gas = air properties,
fixed component efficiencies, no installation losses."""
import math
from dataclasses import dataclass
from . import gas_properties as gp
from .atmosphere import isa
from .nozzle import convergent_nozzle, cd_nozzle

@dataclass
class CycleInputs:
    alt_m: float; mach: float; bpr: float; fpr: float; cpr: float; t4: float
    thrust_N: float | None = None
    pr_inlet: float = 0.98; eta_fan: float = 0.88; eta_hpc: float = 0.86
    eta_b: float = 0.99; pr_b: float = 0.95; eta_hpt: float = 0.89; eta_lpt: float = 0.90
    eta_mech: float = 0.99; pr_bypass_duct: float = 0.99; eta_nozzle: float = 0.98
    lhv: float = 43.1e6
    t7: float | None = None      # afterburner exit total temp [K]; None = dry
    cd_nozzles: bool = False
    eta_ab: float = 0.95; pr_ab: float = 0.94; pr_ab_dry: float = 0.99

def _compress(T, P, pr, eta):
    Ts = gp.T_from_phi(gp.phi(T) + gp.R_GAS * math.log(pr))
    return gp.T_from_h(gp.h(T) + (gp.h(Ts) - gp.h(T)) / eta), P * pr

def _turbine(T, P, w, eta):
    Ts = gp.T_from_h(gp.h(T) - w / eta)
    return gp.T_from_h(gp.h(T) - w), P * math.exp((gp.phi(Ts) - gp.phi(T)) / gp.R_GAS)

def solve_cycle(c: CycleInputs) -> dict:
    if min(c.fpr, c.cpr) <= 1 or c.bpr < 0 or c.mach < 0:
        raise ValueError("Require FPR>1, CPR>1, BPR>=0, Mach>=0")
    T0, P0, _, a0 = isa(c.alt_m)
    V0 = c.mach * a0
    Tt0 = gp.T_from_h(gp.h(T0) + 0.5 * V0**2)
    Pt0 = P0 * math.exp((gp.phi(Tt0) - gp.phi(T0)) / gp.R_GAS)
    Pt2 = Pt0 * c.pr_inlet
    T13, P13 = _compress(Tt0, Pt2, c.fpr, c.eta_fan)
    T3, P3 = _compress(T13, P13, c.cpr, c.eta_hpc)
    # burner energy balance per kg core air: h3 + f*eta_b*LHV = (1+f)*h4
    h4 = gp.h(c.t4)
    if c.t4 <= T3: raise ValueError("T4 must exceed compressor exit temperature")
    f = (h4 - gp.h(T3)) / (c.eta_b * c.lhv - h4)
    P4 = P3 * c.pr_b
    # spool work balances (per kg core air)
    w_hpc = gp.h(T3) - gp.h(T13)
    w_fan = (1 + c.bpr) * (gp.h(T13) - gp.h(Tt0))
    T45, P45 = _turbine(c.t4, P4, w_hpc / (c.eta_mech * (1 + f)), c.eta_hpt)
    T5, P5 = _turbine(T45, P45, w_fan / (c.eta_mech * (1 + f)), c.eta_lpt)
    if P5 <= P0: raise ValueError("LPT exit pressure below ambient: infeasible cycle (lower FPR/BPR or raise T4)")
    if c.t7:
        if c.t7 <= T5: raise ValueError("T7 must exceed LPT exit temperature")
        fab = (gp.h(c.t7) - gp.h(T5)) / (c.eta_ab * c.lhv - gp.h(c.t7))
        ftot = f + (1 + f) * fab; Tn, Pn = c.t7, P5 * c.pr_ab     # fuel per kg core air
    else:
        ftot = f; Tn, Pn = T5, P5 * c.pr_ab_dry
    nz = cd_nozzle if c.cd_nozzles else convergent_nozzle
    core = nz(Tn, Pn, P0, c.eta_nozzle)
    byp = nz(T13, P13 * c.pr_bypass_duct, P0, c.eta_nozzle)
    b = c.bpr
    Fs = ((1 + ftot) * core["V"] + b * byp["V"] - (1 + b) * V0
          + (1 + ftot) * core["pressure_thrust_per_kgs"] + b * byp["pressure_thrust_per_kgs"])  # N per kg/s core
    if Fs <= 0: raise ValueError("Non-positive net thrust")
    mc = c.thrust_N / Fs if c.thrust_N else 1.0
    mdot_total = mc * (1 + b)
    tsfc = ftot / Fs                                            # kg/(N s)
    # effective exhaust velocities fold the pressure-thrust term into momentum (standard convention)
    Ve9 = core["V"] + core["pressure_thrust_per_kgs"]; Ve19 = byp["V"] + byp["pressure_thrust_per_kgs"]
    jet_ke = 0.5 * ((1 + ftot) * Ve9**2 + b * Ve19**2 - (1 + b) * V0**2)
    q_in = ftot * c.lhv
    eta_th = jet_ke / q_in
    eta_p = Fs * V0 / jet_ke if jet_ke > 0 else float("nan")
    checks = dict(
        spool_hp_residual_W=(1 + f) * c.eta_mech * (gp.h(c.t4) - gp.h(T45)) - w_hpc,
        spool_lp_residual_W=(1 + f) * c.eta_mech * (gp.h(T45) - gp.h(T5)) - w_fan,
        propulsive_le_1=eta_p <= 1.0,
        energy_balance_rel=((1 + c.bpr) * gp.h(Tt0) + f * c.eta_b * c.lhv
                            - ((1 + f) * gp.h(T5) + c.bpr * gp.h(T13) + (1 - c.eta_mech) * (1 + f) * (gp.h(c.t4) - gp.h(T5))))
                           / ((1 + c.bpr) * gp.h(Tt0) + f * c.eta_b * c.lhv))
    st = {"0": (T0, P0), "t0": (Tt0, Pt0), "2": (Tt0, Pt2), "13": (T13, P13), "3": (T3, P3),
          "4": (c.t4, P4), "45": (T45, P45), "5": (T5, P5)}
    return dict(stations_Tt_Pt=st, V0=V0, f=ftot, opr=c.fpr * c.cpr,
                specific_thrust_N_per_kgs=Fs / (1 + b), thrust_N=Fs * mc, tsfc_mg_per_Ns=tsfc * 1e6,
                m_core=mc, m_bypass=b * mc, m_total=mdot_total, m_fuel=ftot * mc, f_burner=f, f_total=ftot, afterburning=bool(c.t7), core_nozzle_Tt_Pt=(Tn, Pn),
                V9=core["V"], V19=byp["V"], core_nozzle=core, bypass_nozzle=byp,
                A9_throat_m2=core.get('A_throat_per_kgs', core['area_per_kgs']) * (1 + ftot) * mc, A19_throat_m2=byp.get('A_throat_per_kgs', byp['area_per_kgs']) * b * mc, cd_nozzles=c.cd_nozzles, A9_m2=core["area_per_kgs"] * (1 + ftot) * mc, A19_m2=byp["area_per_kgs"] * b * mc,
                eta_thermal=eta_th, eta_propulsive=eta_p, eta_overall=eta_th * eta_p,
                checks=checks, status="AMBER",
                assumptions=["No cooling bleed", "Hot gas modelled as air", "Fixed component efficiencies",
                             "Design point only (off-design NOT IMPLEMENTED)", "Convergent nozzles only"])
