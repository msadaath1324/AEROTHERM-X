"""Parameter sweeps from the real cycle solver. Each row is a full solve_cycle() call.
Points where the cycle is infeasible are kept with status text, never dropped silently or interpolated.
Fixed-geometry off-design is NOT IMPLEMENTED: sweeps hold the DESIGN-POINT component parameters
(BPR, FPR, CPR, T4) as inputs, i.e. they are re-designed cycles, not one engine flown off-design."""
from dataclasses import replace
import csv, io
import math
from . import gas_properties as gp
from .atmosphere import isa
from .cycle_solver import CycleInputs, solve_cycle

def sweep(base: CycleInputs, param: str, values):
    rows = []
    for v in values:
        try:
            r = solve_cycle(replace(base, **{param: v}))
            rows.append({param: v, "thrust_N": r["thrust_N"], "tsfc_mg_per_Ns": r["tsfc_mg_per_Ns"],
                         "m_total_kg_s": r["m_total"], "fuel_kg_s": r["m_fuel"],
                         "eta_thermal": r["eta_thermal"], "eta_propulsive": r["eta_propulsive"],
                         "eta_overall": r["eta_overall"], "status": "ok"})
        except ValueError as e:
            rows.append({param: v, "status": f"infeasible: {e}"})
    return rows

def to_csv(rows) -> str:
    keys = sorted({k for r in rows for k in r}, key=lambda k: (k == "status", k))
    buf = io.StringIO(); w = csv.DictWriter(buf, fieldnames=keys); w.writeheader(); w.writerows(rows)
    return buf.getvalue()


def lapse(design: CycleInputs, design_result, alts_m, machs, t4_max=None, throttle=1.0):
    """FIXED-SIZE engine, constant-corrected-state approximation (standard first-order off-design):
    * fan-face area & face Mach fixed -> corrected flow m*sqrt(Tt2)/Pt2 constant
    * constant T4/Tt2 (constant corrected speed) -> PRs and component efficiencies held at design values
    * optional T4 flat-rating cap.  Component maps / spool matching / nozzle area scheduling: NOT IMPLEMENTED."""
    Tt2d, Pt2d = design_result["stations_Tt_Pt"]["2"]; md = design_result["m_total"]
    rows = []
    for a in alts_m:
        for M in machs:
            T0, P0, _, a0 = isa(a); V0 = M * a0
            Tt0 = gp.T_from_h(gp.h(T0) + 0.5 * V0 ** 2); Pt2 = P0 * math.exp((gp.phi(Tt0) - gp.phi(T0)) / gp.R_GAS) * design.pr_inlet
            T4 = design.t4 * (Tt0 / Tt2d) * throttle; limited = bool(t4_max and T4 > t4_max); T4 = min(T4, t4_max) if t4_max else T4
            try:
                r = solve_cycle(replace(design, alt_m=a, mach=M, t4=T4, thrust_N=None))
                m_tot = md * (Pt2 / Pt2d) * math.sqrt(Tt2d / Tt0); F = r["specific_thrust_N_per_kgs"] * m_tot
                rows.append(dict(alt_m=a, mach=M, T4=T4, thrust_N=F, tsfc_mg_per_Ns=r["tsfc_mg_per_Ns"], m_total=m_tot, t4_limited=limited, status="ok"))
            except ValueError as e:
                rows.append(dict(alt_m=a, mach=M, status=f"infeasible: {e}"))
    return rows

def sensitivity(base: CycleInputs, params=("bpr", "fpr", "cpr", "t4", "eta_fan", "eta_hpc", "eta_hpt", "eta_lpt", "pr_inlet", "eta_nozzle"), rel=0.01):
    """Elasticities d(ln y)/d(ln x) by 1 % finite difference, at fixed thrust (flow resizes)."""
    r0 = solve_cycle(base); out = []
    for q in params:
        v = getattr(base, q); d = -rel if (q.startswith("eta") or q.startswith("pr_")) else rel
        try:
            r1 = solve_cycle(replace(base, **{q: v * (1 + d)}))
            out.append(dict(param=q, tsfc=(r1["tsfc_mg_per_Ns"] / r0["tsfc_mg_per_Ns"] - 1) / d,
                            specific_thrust=(r1["specific_thrust_N_per_kgs"] / r0["specific_thrust_N_per_kgs"] - 1) / d,
                            airflow=(r1["m_total"] / r0["m_total"] - 1) / d))
        except ValueError: out.append(dict(param=q, tsfc=float("nan"), specific_thrust=float("nan"), airflow=float("nan")))
    return out
