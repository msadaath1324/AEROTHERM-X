"""ISA atmosphere, 0-32 km (ISO 2533 / US Std Atm 1976 layers)."""
import math
G0, R, GAMMA = 9.80665, 287.053, 1.4
_LAYERS = [(0.0, 288.15, 101325.0, -0.0065), (11000.0, 216.65, None, 0.0),
           (20000.0, 216.65, None, 0.001), (32000.0, None, None, None)]

def isa(alt_m: float, dT: float = 0.0):
    """Return (T [K], P [Pa], rho [kg/m3], a [m/s]). dT = ISA temperature offset [K]."""
    if not 0.0 <= alt_m <= 32000.0:
        raise ValueError("Altitude outside implemented ISA range 0-32 km")
    T0, P0 = 288.15, 101325.0
    for i in range(3):
        h0, T0_, _, L = _LAYERS[i]
        h1 = _LAYERS[i + 1][0]
        h = min(alt_m, h1)
        T = T0 + L * (h - h0)
        P = P0 * (T / T0) ** (-G0 / (L * R)) if L else P0 * math.exp(-G0 * (h - h0) / (R * T0))
        if alt_m <= h1:
            break
        T0, P0 = T, P
    Tact = T + dT          # offset applied at constant pressure
    return Tact, P, P / (R * Tact), math.sqrt(GAMMA * R * Tact)
