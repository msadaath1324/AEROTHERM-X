"""Breguet cruise relations (constant V, constant L/D, constant TSFC). L/D, weights are USER inputs; no installation losses."""
import math
G = 9.80665
def breguet(V, tsfc_kg_Ns, ld, W0_kg, W1_kg):
    if not (W0_kg > W1_kg > 0): raise ValueError("Require W0 > W1 > 0")
    k = math.log(W0_kg / W1_kg)
    return dict(range_m=V / (G * tsfc_kg_Ns) * ld * k, endurance_s=ld / (G * tsfc_kg_Ns) * k, fuel_kg=W0_kg - W1_kg)
def required_thrust_per_engine(W_kg, ld, n_engines):
    """Level, unaccelerated flight: T = W/(L/D)."""
    return W_kg * G / ld / n_engines
