"""GREEN/AMBER/RED classification from implemented checks only."""
def validate(res, fan_sizing=None, t4_limit=2000.0, tip_speed_max=470.0):
    items = []
    add = lambda n, ok, msg: items.append((n, "GREEN" if ok else "RED", msg))
    c = res["checks"]
    add("HP spool balance", abs(c["spool_hp_residual_W"]) < 1.0, f"{c['spool_hp_residual_W']:.2e} W per kg/s core")
    add("LP spool balance", abs(c["spool_lp_residual_W"]) < 1.0, f"{c['spool_lp_residual_W']:.2e} W per kg/s core")
    add("Gas-path energy balance", abs(c["energy_balance_rel"]) < 1e-6, f"relative residual {c['energy_balance_rel']:.1e}")
    add("Propulsive efficiency <= 1", c["propulsive_le_1"], f"{res['eta_propulsive']:.3f}")
    add("LPT exit above ambient", res["stations_Tt_Pt"]["5"][1] > res["stations_Tt_Pt"]["0"][1], "Pt5 > P0")
    add("T4 limit", res["stations_Tt_Pt"]["4"][0] <= t4_limit, f"limit {t4_limit} K (uncooled turbine NOT modelled)")
    if res["stations_Tt_Pt"]["4"][0] > 1400.0: items.append(("Turbine cooling", "AMBER", "T4 > 1400 K: cooled turbine needed; cooling flow NOT modelled (results optimistic)"))
    if fan_sizing:
        add("Fan tip speed", 400.0 <= tip_speed_max, "design choice 400 m/s vs limit")
    status = "RED" if any(i[1] == "RED" for i in items) else "AMBER"   # AMBER always: off-design/cooling/benchmarks missing
    return dict(status=status, items=items, why_not_green="Benchmarks, cooling, off-design and component sizing for most parts are NOT IMPLEMENTED")
