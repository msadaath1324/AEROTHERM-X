"""Rule-based preliminary architecture ranking. Heuristic thresholds (textbook rules of thumb), not a proof."""
def recommend(mach: float, bpr: float | None, afterburner: bool, category: str = "") -> dict:
    notes, alts = [], []
    if mach < 0.5 and "prop" in category.lower():
        rec = "Turboprop"; alts = ["Geared turbofan"]
    elif mach >= 1.2:
        rec = "Afterburning turbofan (low BPR)" if (bpr is None or bpr < 1.5) else "Afterburning turbojet"
        alts = ["Adaptive-cycle engine", "Afterburning turbojet"]
        if bpr and bpr >= 1.5: notes.append("BPR >= 1.5 is unsuitable for sustained supersonic flight; consider reducing it")
    elif mach >= 0.7:
        if bpr is None: rec, alts = "High-bypass turbofan", ["Geared turbofan", "Low-bypass turbofan"]; notes.append("BPR not given: assumed from Mach class")
        elif bpr >= 5: rec, alts = "Geared turbofan" if bpr >= 9 else "High-bypass turbofan", ["Separate-flow turbofan"]
        elif bpr >= 1: rec, alts = "Low-bypass turbofan (mixed-flow)", ["High-bypass turbofan"]
        else: rec, alts = "Turbojet", ["Low-bypass turbofan"]
    else:
        rec, alts = "Turboprop" if mach < 0.5 else "High-bypass turbofan", ["Geared turbofan"]
    if afterburner and "Afterburning" not in rec: rec, notes = "Afterburning " + rec.split(" (")[0][0].lower() + rec.split(" (")[0][1:], notes + ["Afterburner requested"]
    return dict(recommended=rec, alternatives=alts, notes=notes,
                missing_info=["required thrust", "mission profile", "installation limits"],
                uncertainty="Preliminary: Mach/BPR alone cannot define an engine")
